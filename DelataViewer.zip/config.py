import os

# Tesseract OCR Path (Adjust if necessary)
# Check for portable version first
local_tesseract = os.path.join(os.getcwd(), 'tesseract', 'tesseract.exe')
if os.path.exists(local_tesseract):
    TESSERACT_CMD = local_tesseract
else:
    # Windows users typically need to point to the executable manually unless it's in PATH
    TESSERACT_CMD = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Overlay Settings
OVERLAY_BG_COLOR = 'black'
OVERLAY_TEXT_COLOR = 'white'
OVERLAY_FONT = ("Helvetica", 12, "bold")
OVERLAY_ALPHA = 0.7  # Transparency (0.0 to 1.0)
OVERLAY_DURATION = 3000  # ms (How long the overlay stays visible)

# Hotkeys
TRIGGER_HOTKEY = 'z'  # Adjust as needed (e.g., Key.f9)

# Image Analysis Settings
# ROI (Region of Interest) relative to cursor or screen center can be defined here if needed
SEARCH_AREA_SIZE = (400, 300) # Width, Height around cursor to search
SAVE_DEBUG_IMAGES = True

