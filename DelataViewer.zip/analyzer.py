import re

import cv2
import numpy as np
import pytesseract
from PIL import Image
import config
import os

class PriceAnalyzer:
    def __init__(self):
        pytesseract.pytesseract.tesseract_cmd = config.TESSERACT_CMD

    def extract_price(self, image):
        """
        Extracts price from the area.
        Strategy: Find all number-like patterns, ignore separators (. and ,), and pick the LARGEST integer.
        This handles cases where price is mixed with other numbers (level, counts) or separators are misread.
        """
        # Convert to grayscale
        gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
        
        # Apply thresholding
        _, thresh = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
        
        # DEBUG: Save image
        cv2.imwrite("debug_price.png", thresh)
        
        # Configure Tesseract
        # Whitelist digits, comma, and dot
        custom_config = r'--oem 3 --psm 6 -c tessedit_char_whitelist=0123456789,.'
        
        text = pytesseract.image_to_string(thresh, config=custom_config)
        
        # DEBUG: Save text
        with open("debug_price.txt", "w", encoding="utf-8") as f:
            f.write(text)
            
        print(f"OCR Raw Text: {text.strip()}", flush=True)
        
        # Parse candidates
        # Regex to find consecutive digits, allowing for commas or dots in between
        # e.g., "33.205" -> "33.205", "27" -> "27", "1,000" -> "1,000"
        # We catch sequences of digits/dots/commas
        matches = re.findall(r'[0-9.,]+', text)
        
        best_price = 0
        
        for match in matches:
            # Normalize: Remove ALL separators to treat as pure integer
            # This works because we assume price is an integer quantity (Silver)
            clean_match = match.replace(',', '').replace('.', '')
            
            if clean_match.isdigit():
                value = int(clean_match)
                
                # Heuristic: Price is usually the largest number
                if value > best_price:
                    best_price = value
                    
        return best_price

class SlotAnalyzer:
    def extract_slots(self, image):
        # 0. Check for user-provided slot images in 'slot_images' folder
        slot_images_dir = "slot_images"
        if os.path.exists(slot_images_dir):
            best_match_score = 0
            best_slot_count = 0
            found_match = False
            
            img_gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
            
            # Iterate through all files in the directory
            for filename in os.listdir(slot_images_dir):
                if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                    try:
                        # Parse filename: slot_{w}_{h}_{total}.png or just {total}.png
                        # Try the new format first: slot_4_3_12.png
                        name_without_ext = os.path.splitext(filename)[0]
                        parts = name_without_ext.split('_')
                        
                        if len(parts) >= 4 and parts[0] == 'slot':
                            # Format: slot_w_h_total
                            slot_count = int(parts[3])
                        else:
                            # Fallback to simple number format: 12.png
                            slot_count = int(name_without_ext)
                        
                        template_path = os.path.join(slot_images_dir, filename)
                        template = cv2.imread(template_path, 0)
                        
                        if template is None:
                            continue
                            
                        # Perform template matching
                        # Ensure template is smaller than image
                        if template.shape[0] > img_gray.shape[0] or template.shape[1] > img_gray.shape[1]:
                            print(f"Skipping {filename}: Template larger than search area.", flush=True)
                            continue
                            
                        res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
                        min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(res)
                        
                        # print(f"Checking {filename}: Score {max_val:.4f}", flush=True)
                        
                        if max_val > best_match_score and max_val > 0.7: # Threshold 0.7
                            best_match_score = max_val
                            best_slot_count = slot_count
                            found_match = True
                            
                    except (ValueError, IndexError):
                        print(f"Skipping {filename}: Invalid filename format. Use 'slot_w_h_total.png' or 'total.png'", flush=True)
                        continue
            
            if found_match:
                print(f"Image Matching Found: {best_slot_count} slots (Score: {best_match_score:.4f})", flush=True)
                return best_slot_count
            else:
                 print("No matching slot image found in 'slot_images'. Falling back...", flush=True)


        # 1. Try Template Matching first if template exists (Single template mode)
        if os.path.exists("slot_template.png"):
            try:
                template = cv2.imread("slot_template.png", 0)
                img_gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
                w, h = template.shape[::-1]
                
                res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
                threshold = 0.8 # Strict match
                loc = np.where(res >= threshold)
                
                # Filter points to avoid multiple counts for same slot
                # Simple non-max suppression or just distance check
                points = []
                for pt in zip(*loc[::-1]):
                    points.append(pt)
                
                # Sort points
                points.sort()
                
                unique_points = []
                min_dist = 10 # Minimum distance between slots
                
                for pt in points:
                    if not unique_points:
                        unique_points.append(pt)
                    else:
                        # Check distance from last point
                        last_pt = unique_points[-1]
                        dist = ((pt[0]-last_pt[0])**2 + (pt[1]-last_pt[1])**2)**0.5
                        if dist > min_dist:
                            unique_points.append(pt)
                            
                count = len(unique_points)
                if count > 0:
                    print(f"Template Matching Found: {count}", flush=True)
                    return count
            except Exception as e:
                print(f"Template matching error: {e}")

        # 2. Fallback to Contour Detection (Original Logic)
        gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
        
        # Apply thresholding to isolate white squares
        # Based on user test, threshold 100 works for 12 slots
        _, thresh = cv2.threshold(gray, 100, 255, cv2.THRESH_BINARY)
        
        # Noise reduction: Remove small white spots
        kernel = np.ones((2,2), np.uint8)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel)
        
        # Find contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        slot_count = 0
        min_area = 50 # Reverted to 50 to filter out noise (Area ~10-40)
        max_area = 2000 # Increased max area just in case
        
        for contour in contours:
            area = cv2.contourArea(contour)
            x, y, w, h = cv2.boundingRect(contour)
            
            # Filter by area and aspect ratio (squares)
            if min_area < area < max_area:
                aspect_ratio = float(w) / h
                if 0.8 < aspect_ratio < 1.2:
                    slot_count += 1
                    
        # Default to 1 if detection fails but price exists? 
        # Or return 0 to indicate failure
        return max(1, slot_count)

class ItemAnalyzer:
    def __init__(self):
        self.price_analyzer = PriceAnalyzer()
        self.slot_analyzer = SlotAnalyzer()

    def analyze(self, image_price_area, image_slot_area):
        price = self.price_analyzer.extract_price(image_price_area)
        slots = self.slot_analyzer.extract_slots(image_slot_area)
        
        return price, slots
