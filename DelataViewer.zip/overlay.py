import tkinter as tk
import config
from threading import Timer
import queue

class Overlay:
    def __init__(self):
        self.root = tk.Tk()
        self.root.overrideredirect(True)
        self.root.wm_attributes("-topmost", True)
        self.root.wm_attributes("-transparentcolor", config.OVERLAY_BG_COLOR)
        self.root.geometry("200x60+0+0") # Increased height slightly
        self.root.config(bg=config.OVERLAY_BG_COLOR) # Set root background to match transparent color
        
        # Main Title Label (Price Per Slot)
        self.title_label = tk.Label(self.root, text="", font=("Arial", 16, "bold"), 
                              fg=config.OVERLAY_TEXT_COLOR, bg=config.OVERLAY_BG_COLOR)
        self.title_label.pack()
        
        # Detail Label (Total / Slots)
        self.detail_label = tk.Label(self.root, text="", font=("Arial", 10), 
                              fg="lightgray", bg=config.OVERLAY_BG_COLOR)
        self.detail_label.pack()
        
        self.hide_timer = None
        self.queue = queue.Queue()
        self.check_queue()

    def check_queue(self):
        try:
            while True:
                msg = self.queue.get_nowait()
                if msg['type'] == 'show':
                    self._show(msg['text'], msg.get('detail_text'), msg['x'], msg['y'])
                elif msg['type'] == 'hide':
                    self._hide()
        except queue.Empty:
            pass
        finally:
            self.root.after(50, self.check_queue) # Faster check 50ms

    def show(self, text, x, y, detail_text=None):
        # Enqueue the request
        self.queue.put({'type': 'show', 'text': text, 'detail_text': detail_text, 'x': x, 'y': y})

    def _show(self, text, detail_text, x, y):
        self.title_label.config(text=text)
        if detail_text:
            self.detail_label.config(text=detail_text)
            self.detail_label.pack()
        else:
            self.detail_label.pack_forget() # Hide if no details
            
        # Position slightly offset from mouse (Above cursor)
        self.root.geometry(f"+{x+20}+{y-60}")
        self.root.deiconify()
        self.root.lift()
        self.root.wm_attributes("-topmost", True)
        
        if self.hide_timer:
            self.hide_timer.cancel()
            
        self.hide_timer = Timer(config.OVERLAY_DURATION / 1000, self.hide)
        self.hide_timer.start()

    def hide(self):
        self.queue.put({'type': 'hide'})

    def _hide(self):
        self.root.withdraw()

    def start(self):
        self.root.withdraw()
        self.root.mainloop()
