import threading
import time
import mss
import mss.tools
import cv2
import numpy as np
import keyboard
import mouse
import config
from analyzer import ItemAnalyzer
from overlay import Overlay
import utils
from PIL import Image
import os

# Global state
overlay = None
analyzer = None

class App:
    def __init__(self):
        self.overlay = Overlay()
        self.analyzer = ItemAnalyzer()
        # self.sct = mss.mss() # MSS is not thread-safe if shared across threads on Windows
        # self.mouse_controller = mouse.Controller() # using 'mouse' lib instead for consistency or just keyboard?
        # Actually 'mouse' lib is good, but let's stick to 'keyboard' for hotkeys.
        # We need mouse position. 'mouse' library is better than pynput for games too.
        pass

    def get_mouse_position(self):
        return mouse.get_position()

    def capture_screen(self):
        # Capture area around mouse
        x, y = self.get_mouse_position()
        width, height = config.SEARCH_AREA_SIZE
        
        monitor = {"top": int(y - height/2), "left": int(x - width/2), "width": width, "height": height}
        
        # Create a new MSS instance for thread safety
        with mss.mss() as sct:
            screenshot = sct.grab(monitor)
            img = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")
            
        return img, x, y

    def on_activate(self):
        # Get mouse position first safely
        x, y = self.get_mouse_position()
        mouse_x, mouse_y = int(x), int(y)

        print("\n[Hotkey Pressed] Starting scan...", flush=True)
        
        # 1. Hide overlay to prevent interference with OCR
        # We need to wait a tiny bit for the UI thread to process the hide command
        self.overlay.hide()
        time.sleep(0.15) 
        
        try:
            # 2. Capture Screen
            # Now the screen should be clear of our overlay
            img, capture_x, capture_y = self.capture_screen()
            
            # 3. Show "Scanning..." AFTER capture
            self.overlay.show("Scanning...", mouse_x, mouse_y)
            
            if config.SAVE_DEBUG_IMAGES:
                img.save("debug_last_capture.png")
                print("Saved debug_last_capture.png", flush=True)

            # Update mouse pos if needed
            mouse_x, mouse_y = int(capture_x), int(capture_y)
            
            # 4. Analyze Image
            cv_img = np.array(img)
            
            # Analyze
            price = self.analyzer.price_analyzer.extract_price(img) # Top-leftish
            slots = self.analyzer.slot_analyzer.extract_slots(img) # Bottom-rightish
            
            print(f"Analysis Result -> Price: {price}, Slots: {slots}", flush=True)

            if price > 0 and slots > 0:
                price_per_slot = int(price / slots)
                
                # New Clean Format
                # Title: 123,456
                # Detail: Total: 1,481,472 | Slots: 12
                # Users requested "Price / Slot" looking clean
                
                title = f"{price_per_slot:,}"
                detail = f"Total: {price:,} | Slots: {slots}"
                
                self.overlay.show(title, mouse_x, mouse_y, detail_text=detail)
            else:
                 self.overlay.show("No Data", mouse_x, mouse_y, detail_text=f"P:{price} S:{slots}")
                
        except Exception as e:
            print(f"Error: {e}", flush=True)
            import traceback
            traceback.print_exc()
            self.overlay.show("Error", mouse_x, mouse_y)

    def run(self):
        print("\n" + "="*40, flush=True)
        print("  Delta Force Game Overlay Started", flush=True)
        print("  Press Ctrl + \\ (Backslash) to scan item", flush=True)
        print("  Press Ctrl + C in this terminal to quit", flush=True)
        print("="*40 + "\n", flush=True)

        # Hotkey listener using keyboard library
        # keyboard.add_hotkey runs in a separate thread automatically for the callback?
        # Actually it's better to keep it simple.
        
        keyboard.add_hotkey(config.TRIGGER_HOTKEY.replace('<', '').replace('>', '').replace('ctrl', 'ctrl').lower(), self.on_activate)
        
        # Exit Hotkey
        keyboard.add_hotkey('shift+z', self.quit_app)
        
        # Show startup message
        try:
            x, y = self.get_mouse_position()
            self.overlay.show("Overlay Ready", int(x), int(y), detail_text="Press 'z' to scan | 'Shift+z' to quit")
        except:
            pass

        # We need to run the tkinter loop in the main thread
        try:
            self.overlay.start()
        except KeyboardInterrupt:
            self.quit_app()

    def quit_app(self):
        print("\nQuitting...", flush=True)
        try:
            self.overlay.root.quit()
        except:
            pass
        os._exit(0)

if __name__ == "__main__":
    app = App()
    try:
        app.run()
    except KeyboardInterrupt:
        app.quit_app()
