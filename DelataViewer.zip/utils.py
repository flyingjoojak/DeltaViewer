import cv2
import numpy as np
from PIL import Image

def preprocess_image(image):
    """
    Preprocess image for better OCR accuracy.
    Converts to grayscale and applies thresholding.
    """
    gray = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2GRAY)
    # Apply thresholding
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return thresh

def parse_price(text):
    """
    Extracts numerical price from text.
    Removes commas and non-numeric characters.
    """
    import re
    # Remove everything except digits
    clean_text = re.sub(r'[^\d]', '', text)
    if not clean_text:
        return 0
    return int(clean_text)
